const chokidar = require('chokidar');
const fs= require('fs');
const Path = require('path');
const Hapi = require('hapi');
const Inert = require('inert');
const server = new Hapi.Server({
    connections: {
        routes: {
            files: {
                relativeTo: Path.join(__dirname, 'build')
            }
        }
    }
});



// array to hold the filenames of the build folders
var pathArray1=[];




// variables holding the templates of the header and footer of both page and posts

var indexHeaderContent=fs.readFileSync('templates/index_h.html','utf-8');

var indexFooterContent=fs.readFileSync('templates/index_f.html','utf-8');

var postHeaderContent=fs.readFileSync('templates/post_h.html','utf-8');

var postFooterContent=fs.readFileSync('templates/post_f.html','utf-8');




// filestream writing the head content in the index.html

fs.writeFileSync(`build/index.html`,indexHeaderContent,'utf-8',(err)=>{
  if(err) throw err;

});




// filestream writing the main title of the homepage

  fs.appendFileSync(`build/index.html`,
  `<h1>The Pages of this mini cms website is </h1>`
    ,"utf-8"
    ,(err)=>{
    if(err) throw err;

  });



// chokidar watching for all the updates in the posts directory while ignoring
// the files with '.' notation. It creates different files in the build directory


var watcher = chokidar.watch('posts/*.txt', {ignored: /(^|[\/\\])\../});

watcher.on('all', (event, path) => {
console.log(path);
var pathArray= path.slice(5).split("/");
pathArray =  pathArray.filter(function(n){ return n!="" });
pathArray1 = pathArray.map(function(n){
   return n.slice(0,-4);
  });

var fileOneData =   fs.readFileSync(path,'utf-8');

    fs.writeFileSync(`build/${pathArray1[0]}.html`,
      indexHeaderContent + postHeaderContent +fileOneData +postFooterContent+indexFooterContent
      ,'utf-8',(err)=>{
      if(err) throw err;
    });


// this stream creates link for the post at the homepage

      fs.appendFileSync(`build/index.html`,
        `
        <li><a href="${pathArray1[0]}.html">${pathArray1[0]}</a></li>
        <p>${fileOneData}</p>
        `
        ,"utf-8"
        ,(err)=>{
        if(err) throw err;
      });

});



// delay to execution for the footer of the homepage

setTimeout(function(){
  fs.appendFileSync(`build/index.html`,indexFooterContent,'utf-8',(err)=>{
    if(err) throw err;
  });
},2000)



// creates a server connection of hapi on port 5000
server.connection({
  host:'localhost',
  port:5000
});


// registering hapi server to use inert for rendering static directory content

server.register(Inert, () => {});


// setting routes for different pages
server.route({
    method: 'GET',
    path: '/{param*}',
    handler: {
        directory: {
            path: '.',
            redirectToSlash: true,
            index: true
        }
    }
});



// finally starting server and displaying the info on console

server.start((err) => {
    if (err) {
        throw err;
    }
    console.log('Server running at:', server.info.uri);
});
